io.write("Hello world, from ", _VERSION, "!\n")
io.flush()

-- This is a single line comment

--[[ 
    This is a Multi Line Comment
]]

--[==[ 
    This is a Multi Line Comment
]==]

