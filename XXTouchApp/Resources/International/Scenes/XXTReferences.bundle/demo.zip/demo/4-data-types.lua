print(type("What is my type"))   --> string
t=10

print(type(5.8*t))               --> number
print(type(true))                --> boolean
print(type(print))               --> function
print(type(type))                --> function
print(type(nil))                 --> nil
print(type(type(ABC)))           --> string

